<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;



Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/user',[UserApiController::class,'index'])->name('user.index');
 Route::post('/user',[UserApiController::class,'store'])->name('user.store');
 Route::get('/user/{id}',[UserApiController::class,'show'])->name('user.show');
 Route::put('/user/{id}',[UserApiController::class,'update'])->name('user.update');
Route::delete('/user/{id}',[UserApiController::class,'destroy'])->name('user.destroy');



// demeli ilk once migrationu yaradiriq sonrada bu migrtaionlarin icini doldurub databaseye baqlayiriq -- php artisan make:migration create_keys_table
//sonrada model yaradiriq eyni adda  --  php artisan make:model Garage
//sonrada controllerler yarat ve controlleri -- php artisan make:controller CarApiController --api  kimi yarat  vess salam
// sonrada api.php faylina get ve orda butun yuxaridakileri yaz ve qurtardi
