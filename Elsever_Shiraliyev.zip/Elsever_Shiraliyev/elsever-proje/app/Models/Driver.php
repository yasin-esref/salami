<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Driver extends Model
{
    protected $fillable = ['user_id', 'key_id', 'name', 'phone' , 'gender', 'experience'];

    use HasFactory;
    public function car()
    {
        return $this->belongsToMany(Car::class);
    }
}
